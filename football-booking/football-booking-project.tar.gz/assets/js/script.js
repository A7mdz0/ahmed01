/**
 * نظام حجز ملاعب كرة القدم - JavaScript
 */

$(document).ready(function() {
    
    // إخفاء الرسائل تلقائياً بعد 5 ثواني
    setTimeout(function() {
        $('.alert').fadeOut('slow');
    }, 5000);
    
    // تأكيد الحذف
    $('.btn-delete').on('click', function(e) {
        if (!confirm('هل أنت متأكد من الحذف؟')) {
            e.preventDefault();
        }
    });
    
    // التحقق من نموذج الحجز
    $('#bookingForm').on('submit', function(e) {
        var startTime = $('#start_time').val();
        var endTime = $('#end_time').val();
        
        if (startTime && endTime && startTime >= endTime) {
            alert('وقت النهاية يجب أن يكون بعد وقت البداية');
            e.preventDefault();
            return false;
        }
    });
    
    // حساب السعر الإجمالي عند تغيير الأوقات
    $('#start_time, #end_time').on('change', function() {
        calculateTotalPrice();
    });
    
    // التحقق من كلمة المرور
    $('#password, #confirm_password').on('keyup', function() {
        var password = $('#password').val();
        var confirmPassword = $('#confirm_password').val();
        
        if (password !== confirmPassword) {
            $('#confirm_password').addClass('is-invalid');
            $('#passwordError').text('كلمات المرور غير متطابقة');
        } else {
            $('#confirm_password').removeClass('is-invalid');
            $('#confirm_password').addClass('is-valid');
            $('#passwordError').text('');
        }
    });
    
    // معاينة الصورة قبل الرفع
    $('#field_image').on('change', function() {
        var file = this.files[0];
        if (file) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#imagePreview').html('<img src="' + e.target.result + '" class="img-thumbnail" style="max-width: 300px;">');
            }
            reader.readAsDataURL(file);
        }
    });
    
    // تفعيل Tooltips
    $('[data-toggle="tooltip"]').tooltip();
    
    // البحث السريع في الجداول
    $('#tableSearch').on('keyup', function() {
        var value = $(this).val().toLowerCase();
        $('#dataTable tbody tr').filter(function() {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
        });
    });
    
    // تحديد الكل في الجدول
    $('#selectAll').on('click', function() {
        $('.select-item').prop('checked', this.checked);
    });
    
    // Smooth scroll للأنكر
    $('a[href^="#"]').on('click', function(event) {
        var target = $(this.getAttribute('href'));
        if(target.length) {
            event.preventDefault();
            $('html, body').stop().animate({
                scrollTop: target.offset().top - 80
            }, 1000);
        }
    });
});

/**
 * حساب السعر الإجمالي للحجز
 */
function calculateTotalPrice() {
    var startTime = $('#start_time').val();
    var endTime = $('#end_time').val();
    var pricePerHour = $('#price_per_hour').val();
    
    if (startTime && endTime && pricePerHour) {
        var start = new Date('2000-01-01 ' + startTime);
        var end = new Date('2000-01-01 ' + endTime);
        
        if (end > start) {
            var hours = (end - start) / (1000 * 60 * 60);
            var totalPrice = hours * parseFloat(pricePerHour);
            
            $('#total_hours').val(hours);
            $('#total_price').val(totalPrice.toFixed(2));
            $('#priceDisplay').html('<strong>السعر الإجمالي: ' + totalPrice.toFixed(2) + ' جنيه</strong>');
        }
    }
}

/**
 * التحقق من التاريخ (لا يسمح بتاريخ ماضي)
 */
function validateDate() {
    var selectedDate = new Date($('#booking_date').val());
    var today = new Date();
    today.setHours(0, 0, 0, 0);
    
    if (selectedDate < today) {
        alert('لا يمكن اختيار تاريخ في الماضي');
        $('#booking_date').val('');
        return false;
    }
    return true;
}

/**
 * تحديث حالة الحجز بـ AJAX
 */
function updateBookingStatus(bookingId, status) {
    if (confirm('هل أنت متأكد من تغيير حالة الحجز؟')) {
        $.ajax({
            url: 'update_booking_status.php',
            method: 'POST',
            data: {
                booking_id: bookingId,
                status: status
            },
            success: function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    alert('حدث خطأ: ' + response.message);
                }
            },
            error: function() {
                alert('حدث خطأ في الاتصال');
            }
        });
    }
}

/**
 * البحث عن الملاعب بـ AJAX
 */
function searchFields() {
    var city = $('#city').val();
    var fieldType = $('#field_type').val();
    var maxPrice = $('#max_price').val();
    
    $.ajax({
        url: 'ajax_search.php',
        method: 'GET',
        data: {
            city: city,
            field_type: fieldType,
            max_price: maxPrice
        },
        beforeSend: function() {
            $('#searchResults').html('<div class="text-center"><div class="spinner-border text-success" role="status"></div></div>');
        },
        success: function(response) {
            $('#searchResults').html(response);
        },
        error: function() {
            $('#searchResults').html('<div class="alert alert-danger">حدث خطأ في البحث</div>');
        }
    });
}

/**
 * إضافة إلى المفضلة
 */
function addToFavorites(fieldId) {
    $.ajax({
        url: 'add_to_favorites.php',
        method: 'POST',
        data: { field_id: fieldId },
        success: function(response) {
            if (response.success) {
                alert('تمت الإضافة إلى المفضلة');
            } else {
                alert(response.message);
            }
        }
    });
}

/**
 * طباعة الصفحة
 */
function printPage() {
    window.print();
}

/**
 * تصدير الجدول إلى CSV
 */
function exportTableToCSV(filename) {
    var csv = [];
    var rows = document.querySelectorAll("table tr");
    
    for (var i = 0; i < rows.length; i++) {
        var row = [], cols = rows[i].querySelectorAll("td, th");
        
        for (var j = 0; j < cols.length; j++) {
            row.push(cols[j].innerText);
        }
        
        csv.push(row.join(","));
    }
    
    downloadCSV(csv.join("\n"), filename);
}

function downloadCSV(csv, filename) {
    var csvFile;
    var downloadLink;
    
    csvFile = new Blob([csv], {type: "text/csv"});
    downloadLink = document.createElement("a");
    downloadLink.download = filename;
    downloadLink.href = window.URL.createObjectURL(csvFile);
    downloadLink.style.display = "none";
    document.body.appendChild(downloadLink);
    downloadLink.click();
}

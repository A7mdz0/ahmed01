    <!-- Footer -->
    <footer class="bg-dark text-white mt-5 py-4">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <h5><i class="fas fa-futbol"></i> ملاعب السودان</h5>
                    <p>منصة حجز ملاعب كرة القدم الأولى في السودان. احجز ملعبك بسهولة وأمان.</p>
                </div>
                <div class="col-md-4">
                    <h5>روابط سريعة</h5>
                    <ul class="list-unstyled">
                        <li><a href="/football-booking/index.php" class="text-white-50 hover-white">الرئيسية</a></li>
                        <li><a href="/football-booking/search.php" class="text-white-50 hover-white">البحث عن ملاعب</a></li>
                        <li><a href="/football-booking/auth/register.php" class="text-white-50 hover-white">تسجيل جديد</a></li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <h5>تواصل معنا</h5>
                    <p><i class="fas fa-envelope"></i> info@footballsd.com</p>
                    <p><i class="fas fa-phone"></i> 0123456789</p>
                    <p><i class="fas fa-map-marker-alt"></i> الخرطوم، السودان</p>
                    <div class="mt-3">
                        <a href="#" class="text-white mr-3"><i class="fab fa-facebook fa-lg"></i></a>
                        <a href="#" class="text-white mr-3"><i class="fab fa-twitter fa-lg"></i></a>
                        <a href="#" class="text-white mr-3"><i class="fab fa-instagram fa-lg"></i></a>
                    </div>
                </div>
            </div>
            <hr class="bg-white">
            <p class="text-center mb-0">&copy; 2025 ملاعب السودان - جميع الحقوق محفوظة</p>
        </div>
    </footer>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo isset($js_path) ? $js_path : '../assets/js/script.js'; ?>"></script>
</body>
</html>

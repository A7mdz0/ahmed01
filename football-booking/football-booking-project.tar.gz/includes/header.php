<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? $page_title : 'نظام حجز ملاعب كرة القدم'; ?></title>
    
    <!-- Bootstrap RTL -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-rtl/3.4.0/css/bootstrap-rtl.min.css">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?php echo isset($css_path) ? $css_path : '../assets/css/style.css'; ?>">
</head>
<body>
    <!-- شريط التنقل -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-success">
        <div class="container">
            <a class="navbar-brand" href="<?php echo isset($home_path) ? $home_path : '/football-booking/index.php'; ?>">
                <i class="fas fa-futbol"></i> ملاعب السودان
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo isset($home_path) ? $home_path : '/football-booking/index.php'; ?>">
                            <i class="fas fa-home"></i> الرئيسية
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo isset($search_path) ? $search_path : '/football-booking/search.php'; ?>">
                            <i class="fas fa-search"></i> البحث
                        </a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <?php if (is_logged_in()): ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" data-toggle="dropdown">
                                <i class="fas fa-user"></i> <?php echo htmlspecialchars($_SESSION['user_name']); ?>
                            </a>
                            <div class="dropdown-menu dropdown-menu-left">
                                <?php if (is_customer()): ?>
                                    <a class="dropdown-item" href="/football-booking/customer/dashboard.php">
                                        <i class="fas fa-tachometer-alt"></i> لوحة التحكم
                                    </a>
                                    <a class="dropdown-item" href="/football-booking/customer/my_bookings.php">
                                        <i class="fas fa-calendar-check"></i> حجوزاتي
                                    </a>
                                <?php elseif (is_owner()): ?>
                                    <a class="dropdown-item" href="/football-booking/owner/dashboard.php">
                                        <i class="fas fa-tachometer-alt"></i> لوحة التحكم
                                    </a>
                                    <a class="dropdown-item" href="/football-booking/owner/my_fields.php">
                                        <i class="fas fa-list"></i> ملاعبي
                                    </a>
                                    <a class="dropdown-item" href="/football-booking/owner/bookings.php">
                                        <i class="fas fa-calendar"></i> الحجوزات
                                    </a>
                                <?php elseif (is_admin()): ?>
                                    <a class="dropdown-item" href="/football-booking/admin/dashboard.php">
                                        <i class="fas fa-tachometer-alt"></i> لوحة الإدارة
                                    </a>
                                <?php endif; ?>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item text-danger" href="/football-booking/auth/logout.php">
                                    <i class="fas fa-sign-out-alt"></i> تسجيل الخروج
                                </a>
                            </div>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="/football-booking/auth/login.php">
                                <i class="fas fa-sign-in-alt"></i> دخول
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link btn btn-outline-light" href="/football-booking/auth/register.php">
                                <i class="fas fa-user-plus"></i> تسجيل جديد
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>
